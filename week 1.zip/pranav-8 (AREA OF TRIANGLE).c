#include<stdio.h>
int main()
{
	int b,h,area;
	printf("enter base and height of the triangle");
	scanf("%d",&b);
	scanf("%d",&h);
	area=(b*h)/2;
	printf("the area of triangle is %d",area);
return 0;
}
