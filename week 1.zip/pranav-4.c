#include<stdio.h>
int main()
{
	int a,b,sum,avg;
	printf("enter any two values");
	scanf("%d",&a);
	scanf("%d",&b);
	sum =a+b;
	avg =sum/2;
	printf("the average of the two numbers is %d\n"+avg);
return 0;
}
