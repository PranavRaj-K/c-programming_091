#include<stdio.h>
int main()
{
	int a;
	printf("enter the value");
	scanf("%d",&a);
	if(a>0)
	{
		printf("the given number is positive");
	}
	else{
	 printf("the givne number is negetive");
}
return 0;
}
