#include <stdio.h>
int main ()
{
	float pi,r,area;
	pi=3.14;
	printf ("enter the radius of the given circle");
	scanf("%f",&r);
	area= pi*r*r;
	printf("the area of the circle is %f",area);
return 0;
}
