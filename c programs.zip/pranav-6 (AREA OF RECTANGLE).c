#include<stdio.h>
int main()
{
	int l,b,area;
	printf("enter the values of length and breadth");
	scanf("%d",&l);
	scanf("%d",&b);
	area=l*b;
	printf("the area of rectangle is %d",area);
return 0;
}
