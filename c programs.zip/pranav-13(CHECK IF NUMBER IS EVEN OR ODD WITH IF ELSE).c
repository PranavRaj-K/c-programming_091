#include<stdio.h>
int main()
{
	int a;
	printf ("enter the value");
	scanf ("%d",&a);
	if(a%2==0)
	{
		printf("the given number is an even number");
	}
	else printf("the given number is an odd number");
	return 0;
}
