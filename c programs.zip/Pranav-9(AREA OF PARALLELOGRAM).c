#include<stdio.h>
int main()
{
	float b,h,area;
	printf("enter the values of breadth and height of the parallelogram");
	scanf("%f%f",&b,&h);
	area=b*h;
	printf("the area of the parallelogram is %f",area);
return 0;
}
