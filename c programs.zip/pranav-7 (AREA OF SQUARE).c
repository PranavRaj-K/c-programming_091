#include<stdio.h>
int main()
{
	int a,area;
	printf("enter the value of side of square");
	scanf("%d",&a);
	area=a*a;
	printf("the are aof square is %d",area);
return 0;
}
