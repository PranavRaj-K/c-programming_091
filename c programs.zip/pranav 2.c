#include<stdio.h>
int main()
{
	int a,b,sum;
	printf ("enter two numbers");
	scanf("%d%d",&a,&b);
	sum=a-b;
	printf("the differnce berween the two numbers is %d",sum);
return 0;
}
