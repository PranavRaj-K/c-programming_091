#include<stdio.h>
int main()
{
	int sub[6],i;
	printf("enter the marks of 6 subjects\n");
	for(i=1;i<=6;i++)
	{
		scanf("%d",&sub[i]);
	}
	printf("the marks of the 6 ")
